package mise.woojeong.com.mise;

import android.location.Location;

/**
 * Created by apple on 2018. 8. 4..
 */

public interface ILocation {
    public void updateDirectionOnObjects(Location location);
}
