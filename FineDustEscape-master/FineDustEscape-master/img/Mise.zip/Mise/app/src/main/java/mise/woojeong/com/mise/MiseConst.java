package mise.woojeong.com.mise;

/**
 * Created by apple on 2018. 7. 21..
 */

public class MiseConst {

    public static final int MISE_GRADE_1 = 1;  //최고
    public static final int MISE_GRADE_2 = 2;  //좋음
    public static final int MISE_GRADE_3 = 3;  //양호
    public static final int MISE_GRADE_4 = 4;  //보통
    public static final int MISE_GRADE_5 = 5;  //나쁨
    public static final int MISE_GRADE_6 = 6;  //상당히 나쁨
    public static final int MISE_GRADE_7 = 7;  //매우 나쁨
    public static final int MISE_GRADE_8 = 8;  //최악


}
