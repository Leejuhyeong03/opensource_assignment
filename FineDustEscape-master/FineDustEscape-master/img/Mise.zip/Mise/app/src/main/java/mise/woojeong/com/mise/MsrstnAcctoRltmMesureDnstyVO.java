package mise.woojeong.com.mise;

import java.util.ArrayList;

/**
 * Created by apple on 2018. 7. 21..
 */

public class MsrstnAcctoRltmMesureDnstyVO {

    private ArrayList<MiseInfoVO> list = new ArrayList<>();

    public ArrayList<MiseInfoVO> getList() {
        return list;
    }

    public void setList(ArrayList<MiseInfoVO> list) {
        this.list = list;
    }
}
