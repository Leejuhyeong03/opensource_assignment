package mise.woojeong.com.mise;

/**
 * Created by apple on 2018. 8. 4..
 */

public class MyLocation {

    private double latitude;
    private double longitude;

    public double getLatitude() {
        return latitude;
    }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    public double getLongitude() {
        return longitude;
    }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

}
