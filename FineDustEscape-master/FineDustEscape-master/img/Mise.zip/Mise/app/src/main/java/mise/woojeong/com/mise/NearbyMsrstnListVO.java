package mise.woojeong.com.mise;

import java.util.ArrayList;

/**
 * Created by apple on 2018. 8. 11..
 */

public class NearbyMsrstnListVO {

    private ArrayList<NearbyMsrstnVO> list = new ArrayList<>();


    public ArrayList<NearbyMsrstnVO> getList() {
        return list;
    }

    public void setList(ArrayList<NearbyMsrstnVO> list) {
        this.list = list;
    }

}
