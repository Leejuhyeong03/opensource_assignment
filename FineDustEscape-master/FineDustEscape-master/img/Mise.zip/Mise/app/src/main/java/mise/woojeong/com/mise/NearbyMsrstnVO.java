package mise.woojeong.com.mise;

/**
 * Created by apple on 2018. 8. 11..
 */

public class NearbyMsrstnVO {

    String addr = "";
    String stationName = "";
    String tm = "";


    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }




}
